// פרוקסי מאובטח ל-Anthropic. המפתח נלקח ממשתנה סביבה ANTHROPIC_API_KEY
// שמוגדר ב-Netlify (Site settings > Environment variables) — לא נחשף בדפדפן.
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { statusCode: 500, body: JSON.stringify({ error: 'ANTHROPIC_API_KEY not set' }) };
  try {
    const { image, media_type, prompt } = JSON.parse(event.body || '{}');
    if (!image) return { statusCode: 400, body: JSON.stringify({ error: 'no image' }) };
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1500,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: media_type || 'image/jpeg', data: image } },
          { type: 'text', text: prompt || 'Extract inventory items as JSON.' }
        ] }]
      })
    });
    const data = await r.json();
    const text = (data.content || []).map(c => c.type === 'text' ? c.text : '').join('');
    return { statusCode: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: String(e) }) };
  }
};
